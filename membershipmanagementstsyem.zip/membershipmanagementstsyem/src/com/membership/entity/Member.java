package com.membership.entity;

import java.io.Serializable;

import com.membership.template.DataObject;

public class Member extends DataObject implements Serializable {

	private static final long serialVersionUID = 6645414878237426556L;
	private String name;
	private String userName;
	private String password;
	private String email;
	private String address;
	private String city;
	private String contactNo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	@Override
	public String toString() {
		return "Member [name=" + name + ", userName=" + userName + ", password=" + password + ", email=" + email
				+ ", address=" + address + ", city=" + city + ", contactNo=" + contactNo + ", message=" +getMessage()+ "]";
	}

}
