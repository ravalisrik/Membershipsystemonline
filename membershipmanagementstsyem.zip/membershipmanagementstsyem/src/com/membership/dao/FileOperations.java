package com.membership.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.membership.entity.Member;

public class FileOperations {
	BufferedWriter bw = null;
	BufferedReader br = null;
	String mainDB = "membership.txt";
	String tempDB = "membershipDB_temp.txt";
	File db = new File(mainDB);

	public boolean saveMember(Member member) {

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(mainDB, true));
			String email=member.getEmail().isEmpty()?" ":member.getEmail();
			String address=member.getAddress().isEmpty()?" ":member.getAddress();
			String city=member.getCity().isEmpty()?" ":member.getCity();
			String conatctNo=member.getContactNo().isEmpty()?" ":member.getContactNo();
			
			bw.write(member.getUserName() + ",@" + member.getPassword() + ",@" + member.getName() + ",@"
					+email + ",@" + address + ",@" + city + ",@"
					+ conatctNo+ ",@");
			bw.flush();
			bw.newLine();
			bw.close();
		} catch (IOException e) {
			return false;
		}

		return true;
	}

	public List<Member> getAllMembers() {
		String record;
		List<Member> memberList = new ArrayList<Member>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(mainDB));
			while ((record = br.readLine()) != null) {

				StringTokenizer st = new StringTokenizer(record, ",@");
				Member member = new Member();

				member.setUserName(st.nextToken());
				member.setPassword(st.nextToken());
				member.setName(st.nextToken());
				member.setEmail(st.nextToken());
				member.setAddress(st.nextToken());
				member.setCity(st.nextToken());
				member.setContactNo(st.nextToken());
				memberList.add(member);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return memberList;
	}

	public boolean delete(String userName) {

		String record;
		boolean isMemberDeleted = false;
		File tempFile = new File(tempDB);
		try {
			BufferedReader br = new BufferedReader(new FileReader(mainDB));

			BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));

			while ((record = br.readLine()) != null) {

				if (record.contains(userName))
					continue;
				bw.write(record);
				bw.flush();
				bw.newLine();

			}

			br.close();
			bw.close();
			db.delete();
			tempFile.renameTo(db);
			isMemberDeleted = true;
		} catch (IOException e) {
		}
		return isMemberDeleted;
	}

	public boolean validate(String userName, String password) {
		String record;
		boolean isvalid = false;
		try {
			BufferedReader br = new BufferedReader(new FileReader(mainDB));

			while ((record = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(record, ",@");

				if (st.nextToken().equalsIgnoreCase(userName)) {
					if (st.nextToken().equalsIgnoreCase(password)) {
						isvalid = true;
						break;
					}

				}

			}
		} catch (IOException e) {

		}
		return isvalid;
	}

	public boolean isUserNameExists(String userName) {

		String record;
		boolean isvalid = false;

		try {
			BufferedReader br = new BufferedReader(new FileReader(mainDB));

			while ((record = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(record, ",@");

				if (st.nextToken().equalsIgnoreCase(userName)) {
					isvalid = true;
					break;
				}

			}
		} catch (IOException e) {
		}

		return isvalid;
	}

	public Member getmember(String userName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(mainDB));
		String record;
		Member member = null;
		while ((record = br.readLine()) != null) {

			StringTokenizer st = new StringTokenizer(record, ",@");
			String uname = st.nextToken();
			if (uname.equalsIgnoreCase(userName)) {
				member = new Member();
				member.setUserName(uname);
				member.setPassword(st.nextToken());
				member.setName(st.nextToken());
				member.setEmail(st.nextToken());
				member.setAddress(st.nextToken());
				member.setCity(st.nextToken());
				member.setContactNo(st.nextToken());

				break;
			}
		}
		br.close();
		return member;

	}

	public boolean update(Member member) throws IOException {
		File tempFile = new File(tempDB);
		String record;
		String record2;
		BufferedReader br = new BufferedReader(new FileReader(mainDB));
		BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));

		String ID = member.getUserName();
		while ((record = br.readLine()) != null) {

			StringTokenizer st = new StringTokenizer(record, ",@");
			if (record.contains(ID)) {

			}

		}

		br.close();

		BufferedReader br2 = new BufferedReader(new FileReader(mainDB));

		while ((record2 = br2.readLine()) != null) {
			if (record2.contains(ID)) {
				bw.write(member.getUserName() + ",@" + member.getPassword() + ",@" + member.getName() + ",@"
						+ member.getEmail() + ",@" + member.getAddress() + ",@" + member.getCity() + ",@"
						+ member.getContactNo());
			} else {

				bw.write(record2);
			}
			bw.flush();
			bw.newLine();
		}

		bw.close();
		br2.close();
		db.delete();
		boolean success = tempFile.renameTo(db);
		return success;

	}
}
