package com.membership.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import com.membership.util.DataBaseConstants;

public class DB {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DataBaseConstants.DRIVER_CLASS);
			con = DriverManager.getConnection(DataBaseConstants.DRIVER_URL, DataBaseConstants.USER_NAME,
					DataBaseConstants.PASSWORD);
		} catch (Exception exception) {
			System.err.println(exception);
		}
		return con;
	}

}
