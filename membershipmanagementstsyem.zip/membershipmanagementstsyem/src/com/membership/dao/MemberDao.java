package com.membership.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.membership.entity.Member;

public class MemberDao {

	public int save(Member member) {
		int status = 0;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"insert into MemberDetails(name,userName,password,email,address,city,contact) values(?,?,?,?,?,?,?)");
			ps.setString(1, member.getName());
			ps.setString(2, member.getUserName().toUpperCase());
			ps.setString(3, member.getPassword());
			ps.setString(4, member.getEmail());
			ps.setString(5, member.getAddress());
			ps.setString(6, member.getCity());
			ps.setString(7, member.getContactNo());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public boolean isUserNameExists(String userName) {
		boolean isExists = false;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from MemberDetails where userName=? ");
			ps.setString(1, userName.toUpperCase());
			ResultSet rs = ps.executeQuery();
			isExists = rs.next();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return isExists;

	}

	public int delete(String userName) {
		int status = 0;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from MemberDetails where userName=?");
			ps.setString(1, userName);
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public boolean validate(String userName, String password) {
		boolean status = false;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from MemberDetails where userName=? and password=?");
			ps.setString(1, userName.toUpperCase());
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public Member getmember(String userName) {
		Member member = null;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from MemberDetails where userName = ?");
			ps.setString(1, userName.toUpperCase());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				member = new Member();
				member.setName(rs.getString("name"));
				member.setUserName(rs.getString("userName"));
				member.setAddress(rs.getString("address"));
				member.setPassword(rs.getString("password"));
				member.setEmail(rs.getString("email"));
				member.setCity(rs.getString("city"));
				member.setContactNo(rs.getString("contact"));
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return member;
	}

	public List<Member> getAllMembers() {
		Member member = null;
		List<Member> membersList = new ArrayList<Member>();
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"select name,userName,email,address,city,contact from MemberDetails",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				member = new Member();
				member = new Member();
				member.setName(rs.getString("name"));
				member.setUserName(rs.getString("userName"));
				member.setAddress(rs.getString("address"));
				member.setEmail(rs.getString("email"));
				member.setCity(rs.getString("city"));
				member.setContactNo(rs.getString("contact"));
				membersList.add(member);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return membersList;
	}

	public int update(Member member) {
		int status = 0;
		try {
			Connection con = DB.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"UPDATE MemberDetails SET name=?,password=?,email=?,address=?,city=?,contact=? where userName=?");
			ps.setString(1, member.getName());
			ps.setString(2, member.getPassword());
			ps.setString(3, member.getEmail());
			ps.setString(4, member.getAddress());
			ps.setString(5, member.getCity());
			ps.setString(6, member.getContactNo());
			ps.setString(7, member.getUserName().toUpperCase());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
}
