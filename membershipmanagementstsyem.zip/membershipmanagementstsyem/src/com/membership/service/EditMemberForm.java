package com.membership.service;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.util.MembershipConstants;

public class EditMemberForm {
	private Member member;
	private boolean isAdmin;

	public EditMemberForm(Member member, boolean isAdmin) {
		super();
		this.member = member;
		this.isAdmin = isAdmin;
	}

	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
	private JPanel contentPane;
	private JTextField textFieldName;
	private JTextField textFieldUserName;
	private JTextField textFieldEmail;
	private JTextField textFieldAddress;
	private JTextField textFieldCity;
	private JTextField textFieldContactNo;
	private JPasswordField passwordField;

	public void launchAddMemberForm(ObjectOutputStream oos, ObjectInputStream ois) {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		JLabel lblAddMember = new JLabel(MembershipConstants.ADD_MEMBER);
		lblAddMember.setForeground(Color.DARK_GRAY);
		lblAddMember.setForeground(Color.BLUE);
		lblAddMember.setFont(new Font("Tahoma", Font.PLAIN, 22));

		JLabel lblName = new JLabel(MembershipConstants.LABEL_NAME);

		JLabel lblUserName = new JLabel(MembershipConstants.LABEL_USER_NAME);

		JLabel lblPassword = new JLabel(MembershipConstants.LABEL_PASSWORD);

		JLabel lblEmail = new JLabel(MembershipConstants.LABEL_EMAIL);

		JLabel lblAddress = new JLabel(MembershipConstants.LABEL_ADDRESS);

		JLabel lblCity = new JLabel(MembershipConstants.LABEL_CITY);

		JLabel lblContactNo = new JLabel(MembershipConstants.LABEL_CONTACT_NO);

		textFieldName = new JTextField();
		textFieldName.setColumns(10);

		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);

		textFieldAddress = new JTextField();
		textFieldAddress.setColumns(10);

		textFieldCity = new JTextField();
		textFieldCity.setColumns(10);

		textFieldContactNo = new JTextField();
		textFieldContactNo.setColumns(10);

		textFieldUserName = new JTextField();
		textFieldUserName.setColumns(10);
		textFieldUserName.setEditable(false);

		passwordField = new JPasswordField();

		JButton btnNewButton = new JButton(MembershipConstants.BTN_SAVE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Member member = new Member();
				member.setName(textFieldName.getText());
				member.setUserName(textFieldUserName.getText());
				member.setPassword(String.valueOf(passwordField.getPassword()));
				member.setEmail(textFieldEmail.getText());
				member.setAddress(textFieldAddress.getText());
				member.setCity(textFieldCity.getText());
				member.setContactNo(textFieldContactNo.getText());

				member.setMessage(MembershipConstants.PROCESS_UPDATE_MEMBER);
				try {
					oos.writeObject(member);
					member = (Member) ois.readObject();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				if (member.getMessage().equals(MembershipConstants.MSG_SUCESS)) {
					JOptionPane.showMessageDialog(frame, MembershipConstants.MSG_MEMBEUPDATED_SUCESS);
					if (isAdmin) {
						AdminServices adminServices = new AdminServices();
						adminServices.launchAdminServices(oos, ois);
					} else {
						MemberServices memberServices = new MemberServices(member.getUserName());
						memberServices.launchMemberServices(oos, ois);
					}

					frame.dispose();

				} else {
					JOptionPane.showMessageDialog(frame, "Sorry, unable to Update the Member!");
				}

			}

		});
		btnNewButton.setForeground(Color.DARK_GRAY);

		JButton btnBack = new JButton(MembershipConstants.BTN_BACK);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (isAdmin) {
					AdminServices adminServices = new AdminServices();
					adminServices.launchAdminServices(oos, ois);
				} else {
					MemberServices memberServices = new MemberServices(member.getUserName());
					memberServices.launchMemberServices(oos, ois);
				}

				frame.dispose();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane
				.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
						.createSequentialGroup().addGap(
								20)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lblPassword, GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
								.addComponent(lblName).addComponent(lblUserName)
								.addComponent(lblEmail, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblAddress, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)
								.addComponent(lblCity, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblContactNo, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE))
						.addGap(58)
						.addGroup(
								gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(textFieldUserName, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
										.addComponent(textFieldContactNo, GroupLayout.DEFAULT_SIZE, 177,
												Short.MAX_VALUE)
										.addComponent(textFieldCity, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
										.addComponent(textFieldAddress, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
										.addComponent(textFieldEmail, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
										.addComponent(textFieldName, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
										.addComponent(passwordField))
						.addContainerGap(107, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(151, Short.MAX_VALUE)
						.addComponent(lblAddMember).addGap(144))
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(160, Short.MAX_VALUE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addGap(133))
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(200, Short.MAX_VALUE)
						.addComponent(btnBack).addGap(30)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addComponent(lblAddMember).addGap(18)

						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addComponent(lblUserName).addGap(18)

										.addComponent(lblPassword))
								.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(textFieldUserName, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)

										.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(passwordField,
												GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)))
						.addGap(18)

						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblName)
								.addComponent(textFieldName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)

						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblEmail)
								.addComponent(textFieldEmail, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblAddress)
								.addComponent(textFieldAddress, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblCity)
								.addComponent(textFieldCity, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblContactNo)
								.addComponent(textFieldContactNo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18)

						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED, 57, Short.MAX_VALUE).addComponent(btnBack)
						.addGap(19)));
		contentPane.setLayout(gl_contentPane);

		doWriteBeanToComponents(member);
	}

	public void doWriteBeanToComponents(Member member) {
		textFieldName.setText(member.getName());
		textFieldUserName.setText(member.getUserName());
		textFieldAddress.setText(member.getAddress());
		textFieldCity.setText(member.getCity());
		textFieldEmail.setText(member.getEmail());
		textFieldContactNo.setText(member.getContactNo());
		passwordField.setText(member.getPassword());
	}

}
