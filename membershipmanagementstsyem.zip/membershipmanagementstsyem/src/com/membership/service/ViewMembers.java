package com.membership.service;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.util.MembershipConstants;

public class ViewMembers {

	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
	private JPanel contentPane;
	private JTable table;
	private boolean isAdmin;
	private String userName;

	public ViewMembers(boolean isAdmin, String userName) {
		super();
		this.isAdmin = isAdmin;
		this.userName = userName;
	}
	
	public static void main(String[] args) {
		ViewMembers members=new ViewMembers(true, "admin");
		members.launchViewMembers(null, null);
	}

	/**
	 * Create the frame.
	 * 
	 * @param ois
	 * @param oos
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	public void launchViewMembers(ObjectOutputStream oos, ObjectInputStream ois) {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setBounds(250, 250, 950, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				e.getWindow().setVisible(false);
				if (isAdmin) {
					AdminServices adminServices = new AdminServices();
					adminServices.launchAdminServices(oos, ois);
				} else {
					MemberServices memberServices = new MemberServices(userName);
					memberServices.launchMemberServices(oos, ois);
				}

			}
		});

		String data[][] = null;
		String column[] = null;

		List<Member> membersList=null;
		Member member1=new Member();
		member1.setMessage(MembershipConstants.PROCESS_VIEWMEMBERS);
		try {
			oos.writeObject(member1);
			membersList = (List<Member>) ois.readObject();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		int cols = membersList.size();
		column = new String[6];

		column[0] = "Name";
		column[1] = "UserName";
		column[2] = "Email";
		column[3] = "City";
		column[4] = "Address";
		column[5] = "ContactNo";

		/*for(Member member: membersList){
			System.out.println(member);
		}*/
		data = new String[cols][6];
		int count = 0;

		for (int i = 1; i <= cols; i++) {
			Member member = membersList.get(count);
			data[count][0] = member.getName();
			data[count][1] = member.getUserName();
			data[count][2] = member.getEmail();
			data[count][3] = member.getCity();
			data[count][4] = member.getAddress();
			data[count][5] = member.getContactNo();
			count++;

		}

		table = new JTable(data, column);
		table.enable(false);
		JScrollPane sp = new JScrollPane(table);
		contentPane.add(sp, BorderLayout.CENTER);

	}

}
