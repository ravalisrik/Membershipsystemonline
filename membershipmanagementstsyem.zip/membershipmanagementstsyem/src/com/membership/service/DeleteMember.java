package com.membership.service;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.util.MembershipConstants;

public class DeleteMember {


	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
	private JPanel contentPane;
	private JTextField textFieldUserName;

	/**
	 * Create the frame.
	 * 
	 * @param ois
	 * @param oos
	 */
	public void launchDeleteMember(ObjectOutputStream oos, ObjectInputStream ois) {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		JLabel lblEnterId = new JLabel(MembershipConstants.ENTER_NAME);

		textFieldUserName = new JTextField();
		textFieldUserName.setColumns(10);

		JButton btnDelete = new JButton(MembershipConstants.BTN_DELETE);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = textFieldUserName.getText();
				if (userName == null || userName.trim().equals("")) {
					JOptionPane.showMessageDialog(frame, MembershipConstants.USERNAME_CANT_BE_BLANK);
				} else {
					Member member = new Member();
					member.setUserName(userName);
					member.setMessage(MembershipConstants.PROCESS_DELETEMEMBER);

					try {
						oos.writeObject(member);
						member = (Member) ois.readObject();
					} catch (Exception e1) {
						e1.printStackTrace();
					}

					if (MembershipConstants.MSG_SUCESS.equals(member.getMessage())) {
						JOptionPane.showMessageDialog(frame, MembershipConstants.MEMBER_DELETED_SUCCESSFULLY);
					} else {
						JOptionPane.showMessageDialog(frame, MembershipConstants.UNABLE_TO_DELETE_GIVEN_MEMBER);
					}
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 13));

		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminServices adminServices = new AdminServices();
				adminServices.launchAdminServices(oos, ois);
				frame.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 13));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(39).addComponent(lblEnterId).addGap(57)
								.addComponent(textFieldUserName, GroupLayout.PREFERRED_SIZE, 178,
										GroupLayout.PREFERRED_SIZE)
								.addContainerGap(107, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING,
								gl_contentPane.createSequentialGroup().addContainerGap(175, Short.MAX_VALUE)
										.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 109,
												GroupLayout.PREFERRED_SIZE)
										.addGap(140))
						.addGroup(Alignment.TRAILING,
								gl_contentPane.createSequentialGroup()
										.addContainerGap(322, Short.MAX_VALUE).addComponent(btnBack,
												GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(19)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(textFieldUserName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblEnterId))
						.addGap(33).addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
						.addGap(43).addComponent(btnBack).addContainerGap(78, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);
	}
}
