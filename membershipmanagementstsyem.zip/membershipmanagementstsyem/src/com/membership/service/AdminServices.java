package com.membership.service;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.template.Client;
import com.membership.util.MembershipConstants;

public class AdminServices {

	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
	private JPanel contentPane;

	private AddMemberForm addMemberForm = new AddMemberForm(true);
	private DeleteMember deleteMember = new DeleteMember();
	

	/**
	 * method for launch the admin services page.
	 * @param ois 
	 * @param oos 
	 * 
	 * @return
	 */
	public void launchAdminServices(ObjectOutputStream oos, ObjectInputStream ois) {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		JLabel lblAdminSection = new JLabel(MembershipConstants.ADMIN_SERVICE);
		lblAdminSection.setForeground(Color.BLUE);
		lblAdminSection.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblAdminSection.setForeground(Color.GRAY);

		JButton btnAddMember = new JButton(MembershipConstants.BTN_ADD_MEMBER);
		btnAddMember.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAddMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addMemberForm.launchAddMemberForm(oos,ois);
				frame.dispose();
			}
		});

		JButton btnEditMember = new JButton(MembershipConstants.BTN_EDIT_MEMBER);
		btnEditMember.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEditMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = JOptionPane.showInputDialog(frame, MembershipConstants.LABEL_EDIT_USERNAME);
				Member member=new Member();
				member.setUserName(userName);
				member.setMessage(MembershipConstants.PROCESS_EDITMEMBER);
				try {
					oos.writeObject(member);
					 member = (Member) ois.readObject();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				if (member.getMessage().equals(MembershipConstants.MSG_MEMBER_NOT_FOUND)) {
					JOptionPane.showMessageDialog(frame, MembershipConstants.LABEL_INVALID_USERNAME);
				} else {
					EditMemberForm editMemberForm = new EditMemberForm(member,true);
					editMemberForm.launchAddMemberForm(oos,ois);
					frame.dispose();
				}
			}
		});

		JButton btnViewAllMembers = new JButton(MembershipConstants.BTN_VIEW_ALL_MEMBER);
		btnViewAllMembers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ViewMembers viewMembers=new ViewMembers(true, "admin");
				viewMembers.launchViewMembers(oos,ois);
				frame.dispose();
			}
		});
		btnViewAllMembers.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JButton btnDeleteMember = new JButton(MembershipConstants.BTN_DELETE_MEMBER);
		btnDeleteMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteMember.launchDeleteMember(oos,ois);
				frame.dispose();
			}
		});
		btnDeleteMember.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JButton btnLogout = new JButton(MembershipConstants.BTN_LOGOUT);
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Client client=new Client();
				frame.dispose();
			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(150, Short.MAX_VALUE)
				.addComponent(lblAdminSection, GroupLayout.PREFERRED_SIZE, 151,GroupLayout.PREFERRED_SIZE)
				.addGap(123))
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup().addGap(134)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(btnLogout, GroupLayout.PREFERRED_SIZE, 181,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(btnDeleteMember, GroupLayout.PREFERRED_SIZE, 181,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(btnViewAllMembers, GroupLayout.PREFERRED_SIZE, 181,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(btnAddMember, GroupLayout.PREFERRED_SIZE, 181,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(btnEditMember, GroupLayout.PREFERRED_SIZE, 181,
												GroupLayout.PREFERRED_SIZE))
								.addContainerGap(109, Short.MAX_VALUE)));

		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addComponent(lblAdminSection, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE).addGap(11)
				.addComponent(btnAddMember, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addComponent(btnEditMember, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addComponent(btnViewAllMembers, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addComponent(btnDeleteMember, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addComponent(btnLogout, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
				.addContainerGap(21, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);
	}
}
