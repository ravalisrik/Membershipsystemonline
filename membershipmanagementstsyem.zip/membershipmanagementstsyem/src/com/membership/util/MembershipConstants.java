package com.membership.util;

public class MembershipConstants {
	public static final String MEMBERSHIP_MANAGEMENT_SYS = "Membership Management System";
	public static final String ADMIN_LOGIN = "Admin Login";
	public static final String MEMBER_LOGIN = "Member Login";
	public static final String ADMIN_LOGIN_FORM = "Admin Login Form";
	public static final String ADD_MEMBER = "Add Member";
	public static final String ENTER_NAME = "Enter UserName:";
	public static final String ENTER_PASSWORD = "Enter Password:";
	
	public static final String ADMIN_SERVICE = "Admin Service";
	public static final String DELETE_SERVICE = "Delete Service";
	public static final String MEMBER_SERVICE ="Member Service         ";

	public static final String BTN_LOGIN = "Login";
	public static final String BTN_LOGOUT = "Logout";
	public static final String BTN_BACK = "Back";
	public static final String BTN_SAVE = "Save";
	public static final String BTN_DELETE = "Delete";

	public static final String BTN_ADD_MEMBER = "Add Member";
	public static final String BTN_EDIT_MEMBER = "Edit Member";
	public static final String BTN_VIEW_ALL_MEMBER = "View All Members";
	public static final String BTN_DELETE_MEMBER = "Delete Member";
	public static final String BTN_GET_MEMBER = "Get Member";
	public static final String BTN_EDIT_PERSONALINFO = "Edit PersonalInfo";
	
	public static final String LABEL_USER_NAME = "User Name:";
	public static final String LABEL_NAME = "Name:";
	public static final String LABEL_PASSWORD = "Password:";
	public static final String LABEL_EMAIL = "Email:";
	public static final String LABEL_ADDRESS = "Address:";
	public static final String LABEL_CITY = "City:";
	public static final String LABEL_CONTACT_NO = "Contact No::";
	public static final String MSG_MEMBERADDED_SUCESS="Member added successfully!";
	public static final String LABEL_REGISTER="Click Here to Register..";
	public static final String LABEL_EDIT_USERNAME="Enter Member UserName to Edit ?";
	public static final String LABEL_INVALID_USERNAME="Sorry,  Invalid UserName !";
	
	public static final String MSG_USRNAME_PSWD_INVALID = "Sorry, Username or Password is Invalid..!";
	public static final String MSG_USRNAME_ALREADY_EXISTS="Sorry, userName Already exists try new one!";
	public static final String GET_MEMB = "Get Member";
	
	public static final String PROCESS_MEMBERLOGIN = "MEMBER_LOGIN";
	public static final String PROCESS_ADMINLOGIN = "ADMIN_LOGIN";
	public static final String PROCESS_EDITMEMBER = "EDIT_MEMBER";
	public static final String PROCESS_ADDMEMBER = "ADD_MEMBER";
	public static final String PROCESS_ISUSEREXISTS = "IS_USER_EXISTS";
	public static final String USERNAME_AVALIABLE = "USERNAME_AVALIABLE";
	public static final String USERNAME_NOTAVALIABLE = "USERNAME_NOT_AVALIABLE";
	
	public static final String PROCESS_DELETEMEMBER = "DELETE_MEMBER";
	public static final String PROCESS_VIEWMEMBERS = "VIEW_ALL_MEMBERS";
	public static final String PROCESS_UPDATE_MEMBER = "UPDATE_MEMBER";
	public static final String EXIT = "EXIT";
	
	public static final String MSG_SUCESS = "SUCESS";
	public static final String MSG_FAILURE = "FAILURE";
	public static final String MSG_MEMBER_FOUND = "MEMBER FOUND";
	public static final String MSG_MEMBER_NOT_FOUND = "MEMBER NOT FOUND";
	public static final Object MSG_PLZ_ENTR_DETAILS = "Please Enter the Form Details";
	
	public static final String USERNAME_CANT_BE_BLANK = "UserName can't be blank";
	public static final String MEMBER_DELETED_SUCCESSFULLY = "Member deleted successfully!";
	public static final String UNABLE_TO_DELETE_GIVEN_MEMBER = "Unable to delete given Member!";
	public static final Object MSG_MEMBEUPDATED_SUCESS = "Member Updated successfully!";

	
	
	
	
	
	
	
	
}
