package com.membership.util;

public class DataBaseConstants {

	public static final String DRIVER_URL = "jdbc:mysql://localhost:3306/membership_management";
	public static final String USER_NAME = "root";
	public static final String PASSWORD = "root";
	public static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	public static final String FILE = "E:/membership/textfile.txt";

}
