package com.membership.template;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import com.membership.dao.FileOperations;
import com.membership.entity.Member;
import com.membership.util.MembershipConstants;

public class Server {
	public static void main(String[] args) throws IOException {

		ServerSocket s = new ServerSocket(4444);

		while (true) {

			Socket incoming = s.accept();
			new Handler(incoming).start();
		}
	}

}

class Handler extends Thread {

	public Handler(Socket s) {
		socket = s;
	}

	public void run() {
		try {
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			System.out.println("Problem constructing streams");
		}
		boolean done = false;
		while (!done) {
			try {
				member = (Member) ois.readObject();
				doProcess(member);
				temp = member.getMessage();
				System.out.println(temp);

				temp = member.getMessage();
				if (temp.equals(MembershipConstants.EXIT)) {
					System.out.println("Streams are closed for client");
					ois.close();
					oos.close();
					socket.close();
				}
			} catch (IOException e) {
				done = true;
			} catch (ClassNotFoundException e) {
				System.out.println("Can't find DataObject!!");
			}

		}
	}

	ObjectInputStream ois;
	ObjectOutputStream oos;
	String temp;
	Socket socket;
	Member member;

	public FileOperations fileOperations = new FileOperations();

	private Member doProcess(Member member) throws IOException {
		System.out.println("Server :: doProcess  :: " + member.getMessage());
		switch (member.getMessage()) {
		case MembershipConstants.PROCESS_MEMBERLOGIN:
			if (fileOperations.validate(member.getUserName(), member.getPassword())) {
				member.setMessage(MembershipConstants.MSG_SUCESS);
			} else {
				member.setMessage(MembershipConstants.MSG_FAILURE);
			}
			break;
		case MembershipConstants.PROCESS_ADMINLOGIN:
			if (member.getUserName().equalsIgnoreCase("ADMIN") && member.getPassword().equals("admin")) {
				member.setMessage(MembershipConstants.MSG_SUCESS);
			} else {
				member.setMessage(MembershipConstants.MSG_FAILURE);
			}
			break;

		case MembershipConstants.PROCESS_EDITMEMBER:
			Member member1 = fileOperations.getmember(member.getUserName());
			if (member1 != null) {
				member.setMessage(MembershipConstants.MSG_MEMBER_FOUND);
				member.setName(member1.getName());
				member.setUserName(member1.getUserName());
				member.setAddress(member1.getAddress());
				member.setPassword(member1.getPassword());
				member.setEmail(member1.getEmail());
				member.setCity(member1.getCity());
				member.setContactNo(member1.getContactNo());

			} else {
				member.setMessage(MembershipConstants.MSG_MEMBER_NOT_FOUND);
			}
			break;

		case MembershipConstants.PROCESS_ISUSEREXISTS:
			if (fileOperations.isUserNameExists(member.getUserName())) {
				member.setMessage(MembershipConstants.USERNAME_NOTAVALIABLE);
			} else {
				member.setMessage(MembershipConstants.USERNAME_AVALIABLE);
			}
			break;

		case MembershipConstants.PROCESS_ADDMEMBER:
			boolean ismemberadded = fileOperations.saveMember(member);
			if (ismemberadded) {
				member.setMessage(MembershipConstants.MSG_SUCESS);
			} else {
				member.setMessage(MembershipConstants.MSG_FAILURE);
			}
			break;

		case MembershipConstants.PROCESS_DELETEMEMBER:
			boolean isdelete = fileOperations.delete(member.getUserName());
			if (isdelete) {
				member.setMessage(MembershipConstants.MSG_SUCESS);
			} else {
				member.setMessage(MembershipConstants.MSG_FAILURE);
			}
			break;

		case MembershipConstants.PROCESS_VIEWMEMBERS:
			List<Member> memberList = fileOperations.getAllMembers();
			oos.writeObject(memberList);
			break;

		case MembershipConstants.PROCESS_UPDATE_MEMBER:
			boolean isupdate = fileOperations.update(member);
			if (isupdate) {
				member.setMessage(MembershipConstants.MSG_SUCESS);
			} else {
				member.setMessage(MembershipConstants.MSG_FAILURE);
			}
			break;

		default:
			break;
		}

		System.out.println("Server ::doProcess :: Message " + member.getMessage());

		if (!member.getMessage().equals(MembershipConstants.PROCESS_VIEWMEMBERS)) {
			oos.writeObject(member);
		}
		return member;
	}
}
