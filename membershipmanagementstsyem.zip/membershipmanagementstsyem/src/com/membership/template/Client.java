package com.membership.template;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.login.AdminLogin;
import com.membership.login.MemberLogin;
import com.membership.util.MembershipConstants;

public class Client extends JFrame implements Runnable {

	DataObject d;
	ObjectInputStream in;
	ObjectOutputStream out;
	Socket socket;

	public Client() {

		try {
			socket = new Socket("127.0.0.1", 4444);
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());

			addWindowListener(new WindowAdapter() {

				public void windowClosing(WindowEvent e) {
					Member member = new Member();
					member.setMessage(MembershipConstants.EXIT);
					try {
						out.writeObject(member);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					System.exit(0);
				}
			});
		} catch (UnknownHostException uhe) {
			System.out.println("Bad URL");
		} catch (IOException ioe) {
			System.out.println("IO Exception");
		}
		Thread thread = new Thread(this, "");
		thread.start();
		setVisible(true);
	}

	public void run() {

		MemberShipHomePage(out, in);
	}

	public static void main(String[] args) {
		Client c = new Client();

	}

	public void MemberShipHomePage(ObjectOutputStream out, ObjectInputStream in) {

		JPanel contentPane;
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);

		JLabel labelMembrManagement = new JLabel(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
		labelMembrManagement.setFont(new Font("Tahoma", Font.PLAIN, 18));
		labelMembrManagement.setForeground(Color.BLUE);

		JButton btnAdminLogin = new JButton(MembershipConstants.ADMIN_LOGIN);
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin adminLogin = new AdminLogin();
				adminLogin.launchAdminLogin(out, in);
				Client.this.dispose();
			}
		});
		btnAdminLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JButton btnMemberLogin = new JButton(MembershipConstants.MEMBER_LOGIN);
		btnMemberLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MemberLogin memberLogin = new MemberLogin();
				memberLogin.launchMemberLogin(out, in);
				Client.this.dispose();
			}
		});
		btnMemberLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(64).addComponent(labelMembrManagement))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(140)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(btnMemberLogin, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(btnAdminLogin, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 135,
												Short.MAX_VALUE))))
				.addContainerGap(95, Short.MAX_VALUE)));

		gl_contentPane
				.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
								.addComponent(labelMembrManagement).addGap(32)
								.addComponent(btnAdminLogin, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(btnMemberLogin,
										GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
								.addContainerGap(70, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);
	}
}