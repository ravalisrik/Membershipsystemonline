package com.membership.template;

import java.io.Serializable;

public class DataObject implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -1534348324342831515L;
	String message = "";

	public void setMessage(String s){

		message = s;

	}
	
	public String getMessage(){

		return message;

	}

}