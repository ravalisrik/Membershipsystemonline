/*package com.membership.login;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.membership.util.MembershipConstants;

public class Membership  {

	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
	private JPanel contentPane;
	private AdminLogin adminLogin = new AdminLogin();
	private MemberLogin memberLogin = new MemberLogin();


	*//**
	 * Create the frame.
	 *//*
	public void  launchMembership() {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		JLabel labelMembrManagement = new JLabel(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);
		labelMembrManagement.setFont(new Font("Tahoma", Font.PLAIN, 18));
		labelMembrManagement.setForeground(Color.BLUE);

		JButton btnAdminLogin = new JButton(MembershipConstants.ADMIN_LOGIN);
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminLogin.launchAdminLogin();
				frame.dispose();
			}
		});
		btnAdminLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JButton btnMemberLogin = new JButton(MembershipConstants.MEMBER_LOGIN);
		btnMemberLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				memberLogin.launchMemberLogin();
			}
		});
		btnMemberLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(64).addComponent(labelMembrManagement))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(140)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(btnMemberLogin, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(btnAdminLogin, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 135,
												Short.MAX_VALUE))))
				.addContainerGap(95, Short.MAX_VALUE)));
		
		gl_contentPane
				.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
								.addComponent(labelMembrManagement).addGap(32)
								.addComponent(btnAdminLogin, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(btnMemberLogin,
										GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
								.addContainerGap(70, Short.MAX_VALUE)));
		contentPane.setLayout(gl_contentPane);
	}
}
*/