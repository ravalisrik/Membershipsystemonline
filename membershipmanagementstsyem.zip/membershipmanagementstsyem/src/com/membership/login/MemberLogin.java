package com.membership.login;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.membership.entity.Member;
import com.membership.service.AddMemberForm;
import com.membership.service.MemberServices;
import com.membership.template.Client;
import com.membership.util.MembershipConstants;

public class MemberLogin extends Thread {
	private JFrame frame = new JFrame(MembershipConstants.MEMBERSHIP_MANAGEMENT_SYS);

	private AddMemberForm addMemberForm = new AddMemberForm(false);

	private JPanel contentPane;
	private JTextField userNameField;
	private JPasswordField passwordField;

	public void launchMemberLogin(ObjectOutputStream oos, ObjectInputStream ois) {
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.WHITE);
		frame.setContentPane(contentPane);

		JLabel lblAdminLoginForm = new JLabel("Member Login Form");
		lblAdminLoginForm.setForeground(Color.BLUE);
		lblAdminLoginForm.setFont(new Font("Tahoma", Font.PLAIN, 18));

		JLabel lblEnterName = new JLabel(MembershipConstants.ENTER_NAME);

		JLabel lblEnterPassword = new JLabel(MembershipConstants.ENTER_PASSWORD);

		JLabel click = new JLabel(MembershipConstants.LABEL_REGISTER);
		click.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				addMemberForm.launchAddMemberForm(oos,ois);
				frame.dispose();

			}
		});

		userNameField = new JTextField();
		userNameField.setColumns(10);

		JButton btnLogin = new JButton(MembershipConstants.BTN_LOGIN);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = userNameField.getText();
				String password = String.valueOf(passwordField.getPassword());
				Member member = new Member();
				member.setUserName(userName);
				member.setPassword(password);
				member.setMessage(MembershipConstants.PROCESS_MEMBERLOGIN);
				try {
					oos.writeObject(member);
					 member = (Member) ois.readObject();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				if (MembershipConstants.MSG_SUCESS.equalsIgnoreCase(member.getMessage())) {
					MemberServices memberServices = new MemberServices(userName);
					memberServices.launchMemberServices(oos,ois);
					frame.dispose();
				} else {
					JOptionPane.showMessageDialog(frame, MembershipConstants.MSG_USRNAME_PSWD_INVALID, "Login Error!",
							JOptionPane.ERROR_MESSAGE);
					userNameField.setText("");
					passwordField.setText("");
				}
			}
		});

		JButton btnBack = new JButton(MembershipConstants.BTN_BACK);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client client = new Client();
				frame.dispose();
			}
		});

		passwordField = new JPasswordField();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(124).addComponent(lblAdminLoginForm))
						.addGroup(gl_contentPane.createSequentialGroup()
								.addGap(19).addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblEnterName).addComponent(lblEnterPassword))
								.addGap(47)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(passwordField)
										.addComponent(userNameField, GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE))))
				.addContainerGap(107, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(187, Short.MAX_VALUE)
						.addComponent(btnLogin, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE).addGap(151))
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addComponent(click))
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(200, Short.MAX_VALUE)
						.addComponent(btnBack).addGap(30)));

		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addComponent(lblAdminLoginForm).addGap(26)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblEnterName)
								.addComponent(userNameField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(28)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(lblEnterPassword)
								.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(18).addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(click))

						.addComponent(btnLogin, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(80, Short.MAX_VALUE).addComponent(btnBack).addGap(19)));
		contentPane.setLayout(gl_contentPane);
	}

}
